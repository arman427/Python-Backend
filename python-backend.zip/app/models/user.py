import uuid
from datetime import datetime

from sqlalchemy import DateTime, String, Text, func, text
from sqlalchemy import Enum as SQLAlchemyEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base
from app.models.enum import Role


class UserORM(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    full_name: Mapped[str] = mapped_column(
        String(100), default="Гость", server_default="Гость"
    )
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(Text, nullable=False)

    role: Mapped[Role] = mapped_column(
        SQLAlchemyEnum(Role), nullable=False, default=Role.STUDENT
    )

    avatar_url: Mapped[str | None] = mapped_column(String(512), nullable=True, default=None)

    refresh_token: Mapped[str | None] = mapped_column(
        String(512), nullable=True, default=None
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    
    student_profile: Mapped["StudentsORM | None"] = relationship(
        "StudentsORM", back_populates="user", uselist=False
    )
    lessons_as_teacher: Mapped[list["LessonORM"]] = relationship(
        "LessonORM", back_populates="teacher"
    )
